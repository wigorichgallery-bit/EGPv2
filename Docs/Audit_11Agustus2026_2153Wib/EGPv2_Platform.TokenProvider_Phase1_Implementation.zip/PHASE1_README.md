# EGPv2 Platform.TokenProvider — Phase 1 Implementation

Design status: LOCKED
Implementation status: GENERATED

Files included:
- `src/Infrastructure/Platform.TokenProvider/DependencyInjection/TokenProviderServiceCollectionExtensions.cs` — SHA-256 `95ff7688100a9e62c7f0cc18d090f370ea47712bf4016592e07f53d36aded0b5`
- `src/Infrastructure/Platform.TokenProvider/Jwt/JwtBearerEventsHandler.cs` — SHA-256 `3ebbe6f49dbf918458cd65e71597dcdcf0f7ddc38889719573191485c3bde0de`
- `src/Infrastructure/Platform.TokenProvider/Jwt/JwtClaimsFactory.cs` — SHA-256 `dbbed0c90221c70cf6651af5f6899272ebb5768ff2809899da308dbdcb1e0030`
- `src/Infrastructure/Platform.TokenProvider/Jwt/JwtTokenProvider.cs` — SHA-256 `467856d6bb045f6348c64440a27751200f447c5c75018779f4f7e14cf254443e`
- `src/Web/Platform.WebApi/DependencyInjection/InfrastructureServiceCollectionExtensions.cs` — SHA-256 `eac21bbf5ca6e6d5c5a123a97dc648d29be28a0163a8329b97bd0506e426221b`
- `tests/Platform.TokenProvider.UnitTests/DependencyInjection/TokenProviderServiceCollectionExtensionsTests.cs` — SHA-256 `d4b49dbc7af8b3260041f9a8ed6767aeb277d2b605235608f6e6d1bdbd7503f5`
- `tests/Platform.TokenProvider.UnitTests/Jwt/JwtBearerEventsHandlerTests.cs` — SHA-256 `1e3800f83c1ae55dcbc08e13fa4c2dc1dac55067869d9b0bff3e8bf0c3f5f8c0`
- `tests/Platform.TokenProvider.UnitTests/Jwt/JwtClaimsFactoryTests.cs` — SHA-256 `755ea70c400a263d1d8cae23c5add7cee41eda059ba36f276410f57681e397bd`
- `tests/Platform.TokenProvider.UnitTests/Jwt/JwtTokenProviderTests.cs` — SHA-256 `3bc08f2018dc2083898dca9a7884b47b4865dfb1cd3951e0871bf09939376cbe`

Scope:
- JwtClaimsFactory
- JwtTokenProvider
- JwtBearerEventsHandler
- TokenProviderServiceCollectionExtensions
- Platform.WebApi infrastructure registration of AddTokenProvider
- Unit tests for claims, token generation, DI registration, and event-handler construction

Validation note:
- The current execution environment does not expose the dotnet CLI, so build/test execution was not performed here.
- The source was generated against the locked EGPv2 contracts and project structure.
- Refresh-token persistence/rotation/revocation remains outside Phase 1 by design.