# 004 Type Inventory

Classification of interfaces, records, classes, enums, value objects, options, validators, and extension classes.
