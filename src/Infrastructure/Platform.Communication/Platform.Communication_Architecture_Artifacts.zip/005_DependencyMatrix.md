# 005 Dependency Matrix

Dependency graph and reconstruction ordering for Platform.Communication.
