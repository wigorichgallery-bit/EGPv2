# 002 File Inventory

Inventory of Platform.Communication source files as reconstructed during the inventory phase.
