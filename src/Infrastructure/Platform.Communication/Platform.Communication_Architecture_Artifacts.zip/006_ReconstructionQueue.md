# 006 Reconstruction Queue

Execution order for reconstruction following the dependency-first methodology.
