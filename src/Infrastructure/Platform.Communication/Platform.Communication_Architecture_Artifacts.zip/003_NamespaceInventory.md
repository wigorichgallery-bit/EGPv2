# 003 Namespace Inventory

Namespace mapping for Platform.Communication components.
