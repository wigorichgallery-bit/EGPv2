# 001 Folder Tree

This document captures the Platform.Communication folder hierarchy based on baseline **EGPv2_230726**.

Refer to `EGPv2_230726_folder_map.txt` for the complete parsed tree.
